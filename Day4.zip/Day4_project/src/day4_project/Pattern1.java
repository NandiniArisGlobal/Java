package day4_project;

public class Pattern1 {
    public static void main(String a[]) {
    	int n=5;
    	for (int i=1;i<=n;i++) {
    		for (int j=1;j<=i;j++) {
    			System.out.print(j);
    		}System.out.print("\n");
    	}
    }
}
